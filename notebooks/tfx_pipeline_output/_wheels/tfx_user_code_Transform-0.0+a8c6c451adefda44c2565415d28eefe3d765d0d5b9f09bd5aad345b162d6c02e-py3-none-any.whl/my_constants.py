# my_constants.py: Primero declare las constantes y la función de utilidad que usará
# Declaro cuáles variables son numéricas, cuáles son categóricas, y cuál es la etiqueta

# Características numéricas que escalarás
NUMERIC_FEATURE_KEYS = [
    "Elevation",
    "Slope",
    "Horizontal_Distance_To_Hydrology",
    "Vertical_Distance_To_Hydrology",
    "Horizontal_Distance_To_Roadways",
    "Hillshade_9am",
    "Hillshade_Noon",
    "Horizontal_Distance_To_Fire_Points"
]

# Características categóricas que convertirás a índices
CATEGORICAL_FEATURE_KEYS = [
    "Soil_Type",
    "Wilderness_Area"
]

# La etiqueta (target) que el modelo predecirá
LABEL_KEY = "Cover_Type"

# (Opcional) Función para renombrar: "Elevation" -> "Elevation_xf"
def transformed_name(key: str) -> str:
    return key + "_xf"
