# my_transform.py

import tensorflow_transform as tft
import my_constants

def preprocessing_fn(inputs):
    """
    Toma un diccionario de tensores crudos (inputs)
    y retorna un diccionario de tensores transformados (outputs).
    """

    outputs = {}

    # 1. Escalar las features numéricas a [0, 1], por ejemplo
    for key in my_constants.NUMERIC_FEATURE_KEYS:
        outputs[my_constants.transformed_name(key)] = tft.scale_to_0_1(
            inputs[key]
        )

    # 2. Convertir las features categóricas a índices
    for cat_key in my_constants.CATEGORICAL_FEATURE_KEYS:
        outputs[my_constants.transformed_name(cat_key)] = tft.compute_and_apply_vocabulary(
            inputs[cat_key]
        )
    
    # 3. Convertir la etiqueta (Cover_Type) también a índice, si lo deseas
    #    (Útil si vas a entrenar con una salida codificada)
    outputs[my_constants.transformed_name(my_constants.LABEL_KEY)] = tft.compute_and_apply_vocabulary(
        inputs[my_constants.LABEL_KEY]
    )

    # Podrías usar otras transformaciones, p.ej.:
    #   tft.scale_by_min_max(), tft.scale_to_z_score(), tft.hash_strings(), etc.

    return outputs